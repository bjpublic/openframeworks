# openFrameworks 가이드 북 소스코드 모음

## 도서정보
* ### 도서명: openFrameworks 가이드북: 크리에이티브 코딩을 위한 최고의 선택
* ### 저자: 서경진
* ### 출판사: BJ퍼블릭
